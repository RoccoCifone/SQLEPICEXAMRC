Create Database ToysGroupRC;


Create Table Category (
CategoryID INT,
CategoryName varchar(50),
constraint PK_CategoryID primary key (CategoryID)
)

Insert Into Category
Values (1, 'Giochi da Tavola'), (2, 'Bambole'), (3, 'Veicoli e modelli')

Select *
from category


Create Table Product (
ProductID INT,
ProductName varchar(50),
CategoryID INT,
StandardCost decimal (10,2),
ListPrice decimal (10,2),
constraint PK_ProductID primary key (ProductID),
constraint FK_CategoryID foreign key (CategoryID)
	References Category(CategoryID)
)

Insert Into Product
Values (1, 'Monopoly', 1, 28, 40), (2, 'Risiko', 1, 30, 45), (3, 'Sapientino', 1, 20, 37), (4, 'Mercante in Fiera', 1, 15, 32), 
(5, 'Barbie', 2, 20, 38), (6, 'Bratz', 2, 22, 40), (7, 'Winks', 2, 17, 35), (8, 'Cicciobello', 2, 25, 45), 
(9, 'Hot Wheels', 3, 10, 22), (10, 'Play mobil', 3, 14, 26), (11, 'Ducati', 3, 15, 28), (12, 'Fiat 500', 3, 20, 40);

Select *
From Product


Create table Region (
RegionID INT,
RegionName Varchar (50),
constraint PK_RegionID primary key (RegionID)
)

Insert Into Region
Values (1, 'South Europe'), (2, 'Continental Europe')

Select*
From Region

Create Table States (
StateID INT,
StateName Varchar(50),
RegionID INT, 
Constraint PK_StateID primary key (StateID),
constraint FK_RegionID foreign key (RegionID)
references Region(RegionID)
)

Insert Into States
Values (1, 'Italy', 1), (2, 'Germany', 2), (3, 'France', 2), (4, 'Spain', 1)

Select*
From States



Create table Sales(
OrderID INT,
OrderData Date,
ProductID INT,
StateID INT,
Quantity INT,
ListPrice DECIMAL (10,2),
SalesAmount DECIMAL (10,2),
constraint PK_OrderID primary key (OrderID),
constraint FK_ProductID foreign key (ProductID)
references Product(ProductID),
constraint FK_StateID foreign key (StateID)
references States(StateID)
);

Insert Into Sales
Values	(1, '2024-01-31', 2, 4, 400, 45, 18000),
		(2, '2024-01-31', 8, 4, 320, 45, 14400),
		(3, '2023-05-31', 9, 1, 600, 22, 13200),
		(4, '2024-01-31', 3, 2, 250, 37, 9250),
		(5, '2024-01-31', 6, 2, 280, 40, 11200),
		(6, '2024-01-31', 11, 2, 700, 28, 19600),
		(7, '2023-04-30', 12, 1, 100, 40, 4000),
		(8, '2023-04-30', 1, 1, 1000, 40, 40000),
		(9, '2023-12-31', 5, 3, 200, 38, 7600),
		(10, '2023-12-31', 4, 3, 460, 32, 14720),
		(11, '2023-12-31', 10, 3, 820, 26, 21320),
		(12, '2023-12-31', 3, 3, 1200, 37, 44400);

Select*
From Sales

Select CategoryID, Count(CategoryID) as conteggi
From Category
Group by CategoryID

Select ProductID, Count(ProductID) as conteggi
From Product
Group by ProductID

Select RegionID, Count(RegionID) as conteggi
From Region
Group by RegionID

Select StateID, Count(StateID) as conteggi
From States
Group by StateID

Select OrderID, Count(OrderID) as conteggi
From Sales
Group by OrderID

-- opzione 1

Select	Sales.OrderID, 
		Sales.OrderData, 
		Product.ProductName, 
		Category.CategoryName, 
		States.StateName, 
		Region.RegionName,
		case 
		when OrderData < '2023-08-04' then 'True'
		Else 'False'
		END
From Sales
inner join Product
ON Sales.ProductID = Product.ProductID
inner join Category
ON Product.CategoryID = Category.CategoryID
inner join States
ON Sales.StateID = States.StateID
inner join Region
on States.RegionID = Region.RegionID

-- opzione 2

Select	Sales.OrderID, 
		Sales.OrderData, 
		Product.ProductName, 
		Category.CategoryName, 
		States.StateName, 
		Region.RegionName,
		case 
		when DATEDIFF( day, MAX(sales.OrderData), GETDATE()) > 180 then 'True'
		Else 'False'
		END
From Sales
inner join Product
ON Sales.ProductID = Product.ProductID
inner join Category
ON Product.CategoryID = Category.CategoryID
inner join States
ON Sales.StateID = States.StateID
inner join Region
on States.RegionID = Region.RegionID
Group by OrderID, OrderData, product.ProductName, Category.CategoryName, 
		States.StateName, 
		Region.RegionName
Order by OrderData


-- Elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

Select Sales.ProductID, Product.ProductName, year(Sales.OrderData) as YEARS, sum(Sales.SalesAmount) as totalSales
From Sales
inner join Product
on Sales.ProductID = Product.ProductID
Group by Sales.ProductID, Product.ProductName, year(Sales.OrderData)

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente

Select Sales.StateID, States.StateName, year(Sales.OrderData) as YEARS, sum(Sales.SalesAmount) as totalSales
From Sales
inner join States
on Sales.StateID = States.StateID
group by Sales.StateID, States.StateName, year(Sales.OrderData)

-- Quale � la categoria di articoli maggiormente richiesta dal mercato

Select Category.CategoryName, Sum(Sales.Quantity) As TotalQuantity
From Sales
Inner join Product
On Sales.ProductID = Product.ProductID
Inner join Category
on Product.CategoryID = Category.CategoryID
Group by  Category.CategoryName 
having sum(Sales.Quantity) >1
Order By TotalQuantity desc

-- Quali sono, se ci sono, i prodotti invenduti?

Select ProductID, ProductName
From Product
where ProductID not in (Select ProductID
						From Sales)


-- Esporre elenco prodotti con la rispettiva ultima data di vendita

Select Product.ProductName, max(Sales.OrderData) as MaxOrderDate
From Sales
inner join Product
on Sales.ProductID = Product.ProductID
Group by Product.ProductName, Sales.OrderData
order by MaxOrderDate desc


-- Creare View Prodotti

Create View VW_RC_Product AS (

Select	Product.ProductID,
		Product.ProductName,
		Category.CategoryName
From Product
Inner join Category
on Product.CategoryID = Category.CategoryID
);

-- Creare View info Geografiche

Create View VW_RC_Geographicareas AS (

Select	States.StateID, 
		States.StateName,
		Region.RegionName
From States
inner join Region
on States.RegionID = Region.RegionID
)

Create View VW_RC_Sales AS (
Select *
From Sales
)